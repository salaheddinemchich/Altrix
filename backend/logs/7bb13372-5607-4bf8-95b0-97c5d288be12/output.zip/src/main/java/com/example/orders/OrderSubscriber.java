package com.example.orders;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.header.HeaderAccessor;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * Subscribes to the orders topic and processes each message.
 * The idiomatic Spring Kafka consumer.
 */
@Service
public class OrderSubscriber {

    private static final Logger log = LoggerFactory.getLogger(OrderSubscriber.class);

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @PostConstruct
    public void init() {
        // No explicit subscription needed for @KafkaListener
        log.info("Waiting for messages from topic {}", PubSubConfig.ORDERS_TOPIC);
    }

    @KafkaListener(topics = PubSubConfig.ORDERS_TOPIC)
    public void handle(
            @Payload String payload,
            @Header(KafkaHeaders.RECEIVED_OFFSET) long offset,
            HeaderAccessor headerAccessor) {

        Order order = Order.fromMessage(payload);
        log.info("Processing order {} ({} x{}) with offset {}", 
                order.id(), order.product(), order.quantity(), offset);

        // Acknowledgment is automatic in Spring Kafka for @KafkaListener
        // No manual ack() call needed
    }
}